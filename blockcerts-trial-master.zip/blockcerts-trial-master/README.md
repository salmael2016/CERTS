# blockcerts-trial
This is a demo repo for blockcerts.

Used in the blog article https://xiaoxing.us/2018/01/31/Utilizing-BlockCert-Blockchain-Based-Educational-Certificates/
